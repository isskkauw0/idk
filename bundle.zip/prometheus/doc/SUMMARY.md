# Table of contents

* [Prometheus Documentation](README.md)

## Getting Started

* [Installation](getting-started/installation.md)
* [Quickstart: First Obfuscation](getting-started/quickstart-first-obfuscation.md)
* [Troubleshooting](getting-started/troubleshooting.md)

## Guides

* [CLI Usage](guides/cli-usage.md)
* [Presets](guides/presets.md)
* [Writing a Custom Config](guides/writing-a-custom-config.md)
* [Using Prometheus as a Library](guides/using-as-a-library.md)

## Reference

* [Limitations](reference/limitations.md)
* [CLI Options Reference](reference/cli-options.md)
* [Config Object Reference](reference/config-object.md)
* [Step Pipeline Overview](reference/steps/overview.md)
* [Step: WrapInFunction](reference/steps/wrapinfunction.md)
* [Step: Cff](reference/steps/cff.md)
* [Step: Vmify](reference/steps/vmify.md)
* [Step: SplitStrings](reference/steps/splitstrings.md)
* [Step: ProxifyLocals](reference/steps/proxifylocals.md)
* [Step: EncryptStrings](reference/steps/encryptstrings.md)
* [Step: ConstantArray](reference/steps/constantarray.md)
* [Step: AntiTamper](reference/steps/anti-tamper.md)
* [Step: NumbersToExpressions](reference/steps/numberstoexpressions.md)
* [Step: AddVararg](reference/steps/addvararg.md)
* [Step: WatermarkCheck](reference/steps/watermarkcheck.md)

## Advanced

* [How the Pipeline Works](advanced/how-the-pipeline-works.md)
* [AST Bindings](advanced/ast-bindings.md)
* [Register VM](advanced/register-vm.md)
