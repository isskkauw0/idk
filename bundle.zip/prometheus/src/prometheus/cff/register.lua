-- This Script is Part of the Prometheus Obfuscator by levno-710
--
-- register.lua
--
-- This Script contains the register management for the compiler.

local Ast = require("prometheus.ast");
local constants = require("prometheus.cff.constants");

local MAX_REGS = constants.MAX_REGS;

return function(Compiler)
    function Compiler:freeRegister(id, force)
        if force or not (self.registers[id] == self.VAR_REGISTER) then
            -- Releasing an allocator slot must also release its runtime reference.
            -- Control/return slots are reserved and never contain temporaries.
            if id ~= self.POS_REGISTER and id ~= self.RETURN_REGISTER then
                self:addStatement(self:setRegister(id, Ast.NilExpression()), {id}, {}, false, true);
            end
            self.usedRegisters = self.usedRegisters - 1;
            self.registers[id] = false
        end
    end

    function Compiler:isVarRegister(id)
        return self.registers[id] == self.VAR_REGISTER;
    end

    function Compiler:allocRegister(isVar)
        self.usedRegisters = self.usedRegisters + 1;

        -- Dispatch position and final returns outlive ordinary temporary slots.

        local id = 0;
        if self.usedRegisters < MAX_REGS * constants.MAX_REGS_MUL then
            repeat
                id = math.random(1, MAX_REGS - 1);
            until not self.registers[id];
        else
            repeat
                id = id + 1;
            until not self.registers[id];
        end

        if id > self.maxUsedRegister then
            self.maxUsedRegister = id;
        end

        if(isVar) then
            self.registers[id] = self.VAR_REGISTER;
        else
            self.registers[id] = true
        end
        return id;
    end

    function Compiler:isUpvalue(scope, id)
        return self.upvalVars[scope] and self.upvalVars[scope][id];
    end

    function Compiler:makeUpvalue(scope, id)
        if(not self.upvalVars[scope]) then
            self.upvalVars[scope] = {}
        end
        self.upvalVars[scope][id] = true;
    end

    function Compiler:getVarRegister(scope, id, functionDepth, potentialId)
        if(not self.registersForVar[scope]) then
            self.registersForVar[scope] = {};
            self.scopeFunctionDepths[scope] = functionDepth;
        end

        local reg = self.registersForVar[scope][id];
        if not reg then
            if potentialId and self.registers[potentialId] ~= self.VAR_REGISTER and potentialId ~= self.POS_REGISTER and potentialId ~= self.RETURN_REGISTER then
                self.registers[potentialId] = self.VAR_REGISTER;
                reg = potentialId;
            else
                reg = self:allocRegister(true);
            end
            self.registersForVar[scope][id] = reg;
        end
        return reg;
    end

    function Compiler:getRegisterVarId(id)
        local varId = self.registerVars[id];
        if not varId then
            varId = Ast.LocalSymbol();
            self.registerVars[id] = varId;
        end
        return varId;
    end

    function Compiler:register(id)
        if id == self.POS_REGISTER then
            return self:pos();
        end

        if id == self.RETURN_REGISTER then
            return self:getReturn();
        end

        if id < MAX_REGS then
            local vid = self:getRegisterVarId(id);
            return Ast.VariableExpression(vid);
        end

        local vid = self:getRegisterVarId(MAX_REGS);
        return Ast.IndexExpression(Ast.VariableExpression(vid), Ast.NumberExpression((id - MAX_REGS) + 1));
    end

    function Compiler:registerList(ids)
        local l = {};
        for i, id in ipairs(ids) do
            table.insert(l, self:register(id));
        end
        return l;
    end

    function Compiler:registerAssignment(id)
        if id == self.POS_REGISTER then
            return self:posAssignment();
        end
        if id == self.RETURN_REGISTER then
            return self:returnAssignment();
        end

        if id < MAX_REGS then
            local vid = self:getRegisterVarId(id);
            return Ast.AssignmentVariable(vid);
        end

        local vid = self:getRegisterVarId(MAX_REGS);
        return Ast.AssignmentIndexing(Ast.VariableExpression(vid), Ast.NumberExpression((id - MAX_REGS) + 1));
    end

    function Compiler:setRegister(id, val, compundArg)
        if(compundArg) then
            return compundArg(self:registerAssignment(id), val);
        end
        return Ast.AssignmentStatement({
            self:registerAssignment(id)
        }, {
            val
        });
    end

    function Compiler:setRegisters(ids, vals)
        local idStats = {};
        for i, id in ipairs(ids) do
            table.insert(idStats, self:registerAssignment(id));
        end

        return Ast.AssignmentStatement(idStats, vals);
    end

    function Compiler:copyRegisters(to, from)
        local idStats = {};
        local vals = {};
        for i, id in ipairs(to) do
            local fromId = from[i];
            if(fromId ~= id) then
                table.insert(idStats, self:registerAssignment(id));
                table.insert(vals, self:register(fromId));
            end
        end

        if(#idStats > 0 and #vals > 0) then
            return Ast.AssignmentStatement(idStats, vals);
        end
    end

    function Compiler:resetRegisters()
        self.registers = {};
    end

    function Compiler:pos()
        return Ast.VariableExpression(self.posVar);
    end

    function Compiler:posAssignment()
        return Ast.AssignmentVariable(self.posVar);
    end

    function Compiler:args()
        return Ast.VariableExpression(self.argsVar);
    end

    function Compiler:unpack()
        return Ast.VariableExpression(self.unpackPackedVar);
    end

    function Compiler:pack(values)
        return Ast.FunctionCallExpression(Ast.VariableExpression(self.packVar), values);
    end

    function Compiler:env()
        return Ast.VariableExpression(self.currentEnvVar);
    end

    function Compiler:functionCall(reg, args)
        local callArgs = {self:register(reg), self:env()};
        for _, arg in ipairs(args) do table.insert(callArgs, arg); end
        return Ast.FunctionCallExpression(Ast.VariableExpression(self.callFunctionVar), callArgs);
    end

    function Compiler:jmp(to)
        return Ast.AssignmentStatement({Ast.AssignmentVariable(self.posVar)},{to});
    end

    function Compiler:setPos(val)
        if not val then
            return Ast.AssignmentStatement({Ast.AssignmentVariable(self.posVar)}, {Ast.NilExpression()});
        end
        return Ast.AssignmentStatement({Ast.AssignmentVariable(self.posVar)}, {Ast.NumberExpression(val) or Ast.NilExpression()});
    end

    function Compiler:setReturn(val)
        return Ast.AssignmentStatement({Ast.AssignmentVariable(self.returnVar)}, {val});
    end

    function Compiler:getReturn()
        return Ast.VariableExpression(self.returnVar);
    end

    function Compiler:returnAssignment()
        return Ast.AssignmentVariable(self.returnVar);
    end

    function Compiler:setUpvalueMember(idExpr, valExpr, compoundConstructor)
        if compoundConstructor then
            return compoundConstructor(Ast.AssignmentIndexing(Ast.VariableExpression(self.upvaluesTable), idExpr), valExpr);
        end
        return Ast.AssignmentStatement({Ast.AssignmentIndexing(Ast.VariableExpression(self.upvaluesTable), idExpr)}, {valExpr});
    end

    function Compiler:getUpvalueMember(idExpr)
        return Ast.IndexExpression(Ast.VariableExpression(self.upvaluesTable), idExpr);
    end
end

