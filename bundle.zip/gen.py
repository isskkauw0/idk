import os
S = {
	"weak": [("Cff", "{}"), ("ConstantArray", "{Threshold=1,StringsOnly=true}"), ("WrapInFunction", "{}")],
	"medium": [("Vmify", "{}"), ("EncryptStrings", "{HoistVmStrings=true}"), ("AntiTamper", "{UseDebug=false}"), ("ConstantArray", "{Threshold=1,StringsOnly=true,Shuffle=true,Rotate=true,LocalWrapperThreshold=0}"), ("WrapInFunction", "{}"), ("Cff", "{ExcludeVm=true}"), ("NumbersToExpressions", "{}")],
	"strong": [("Vmify", "{}"), ("EncryptStrings", "{}"), ("AntiTamper", "{UseDebug=false}"), ("Cff", "{}"), ("ConstantArray", "{Threshold=1,StringsOnly=true,Shuffle=true,Rotate=true,LocalWrapperThreshold=0}"), ("NumbersToExpressions", "{NumberRepresentationMutation=true}"), ("WrapInFunction", "{}")],
}
for p, st in S.items():
	os.makedirs(f"cfg/{p}", exist_ok=True)
	for m in range(1, 2 ** len(st)):
		sel = [st[i] for i in range(len(st)) if m >> i & 1]
		body = ",".join('{Name="%s",Settings=%s}' % x for x in sel)
		open("cfg/%s/%s.lua" % (p, "+".join(x[0] for x in sel)), "w").write('return {LuaVersion="LuaU",VarNamePrefix="",NameGenerator="MangledShuffled",PrettyPrint=false,Seed=0,Steps={%s}}' % body)
