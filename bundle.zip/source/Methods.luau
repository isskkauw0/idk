local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Object = {Nested = {Deep = {}}}

function Object.Plain(X)
	return X
end

function Object:Method(X)
	return self, X
end

function Object.Nested.Deep.Static()
	return "static"
end

function Object.Nested.Deep:Instance()
	return self
end

Object.Nested.Deep.Field = function()
	return 1
end

function GlobalFunction(...)
	return ...
end

Object:Method(1)
Object:Method(2)
Object.Method(Object, 3)
Object["Method"](Object, 4)
Object.Nested.Deep:Instance()
Object.Nested.Deep.Instance(Object.Nested.Deep)
Object.Plain(Object.Nested.Deep.Static())
Object.Plain(Object.Nested.Deep.Field())
GlobalFunction(1, 2, 3)
GlobalFunction()
