local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Shadow = 1
local Shadow = Shadow + 1
local Shadow = Shadow * 2
do
	local Shadow = Shadow + 100
	do
		local Shadow = Shadow + 1000
		Passthrough(Shadow)
	end
end
local Outer = 1
do
	local Outer = Outer + 1
	do
		local Outer = Outer + 1
		Passthrough(Outer)
	end
end
do
	do
		do
			local Deep = "deep"
			Passthrough(Deep)
		end
	end
end
local function Parameter(Shadow)
	local Shadow = Shadow or 0
	return Shadow
end
local ParameterA, ParameterB = Parameter(1), Parameter()
for Shadow = 1, 2 do
	local Shadow = Shadow * 2
	Passthrough(Shadow)
end
for Shadow in {1} do
end
Passthrough(ParameterA, ParameterB)
