local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Folder = Instance.new("Folder")
Folder.Name = "Test"
Folder:SetAttribute("Count", 1)
Folder:SetAttribute("Count", Folder:GetAttribute("Count") + 1)
local Part = Instance.new("Part")
Part.Anchored = true
Part.Size = Vector3.new(1, 2, 3)
Part.CFrame = CFrame.new(0, 10, 0) * CFrame.Angles(0, math.rad(90), 0)
Part.Color = Color3.fromRGB(255, 0, 0)
Part.Material = Enum.Material.Plastic
Part.Parent = Folder
local Event = Instance.new("BindableEvent")
local Connection = Event.Event:Connect(function(...)
	return ...
end)
Event.Event:Once(function() end)
Event:Fire(1, 2, 3)
Connection:Disconnect()
Folder.ChildAdded:Connect(function(Added)
	Added.Name = "Added"
end)
task.spawn(function(...) end, 1, 2)
task.defer(function() end)
task.delay(1, function() end)
task.wait()
local Running = game:GetService("RunService"):IsRunning()
local Position= Vector3.new(1, 2, 3) * 2 + Vector3.zero - Vector3.one
local Dot = Position:Dot(Vector3.xAxis)
local Size = UDim2.new(0.5, 0, 0.5, 0)
local IsVector = typeof(Position) == "Vector3"
Event:Destroy()
Folder:Destroy()
Passthrough(Running, Dot, Size, IsVector)
