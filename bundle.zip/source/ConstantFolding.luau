local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Folded = 1 + 2 * 3 - math.floor(4 / 2 / 1 )% 5 ^ 2
local FoldedString = "a" .. "b" .. "c"
local FoldedLength = #"abc"
local FoldedLogic = not nil and not false or nil
local FoldedCompare = 1 < 2 and "a" < "b" and 1 == 1 and "x" ~= "y"
local FoldedBuiltin = math.pi * 2 + math.huge
local FoldedIf = true and 1 or 2
local FoldedAnd = false and error("never") or 5
local FoldedOr = true or error("never")
local NaN = 0 / 0
local Infinite = 1 / 0
local NegativeInfinite = -1 / 0
local NegativeZero = -0
local IsNaN = NaN ~= NaN
if true then
	FoldedLength =FoldedLength+ 1
end
if false then
	FoldedLength =FoldedLength- 1
else
	FoldedLength =FoldedLength* 2
end
if nil then end
if 0 then end
if "" then end
while false do end
repeat until true

local function Square(X)
	return X * X
end

local function EarlyReturn(Flag)
	if Flag then
		return "early"
	end
	do
		return "late"
	end
end

local function Unreachable()
	do return 1 end
	return 2
end

local Immutable = 5

local function UsesImmutable()
	return Immutable + 1
end

local UsedA, UsedB = UsesImmutable(), UsesImmutable()
local SquaredA, SquaredB = Square(4), Square(Folded)
local EarlyA, EarlyB = EarlyReturn(true), EarlyReturn(false)
local UnreachedA, UnreachedB = Unreachable(), Unreachable()
local Total = 0
for Index = 1, 4 do
	Total =Total+ Index
end
local Value = Total
local Result = Value == nil and "nil" or Value == true and "true" or Value == 10 and "ten" or Value == "x" and "x" or "other"
local Fallback = Value or {}
Value = Value and Value + 1
local Default = nil
Default = Default or {}
local Ternary = Value and Value > 5 and "big" or "small"
local Negated = not (Value == 1 or Value == 2) and not (Value ~= 3)
local LongCondition = (Value == 1 and Value == 2) or (Value == 3 and not Default) or (not Value and Default) or (1 < 2 == true)
local DeepParens = ((((((((1))))))))
local Comparisons = Value < 1 or Value <= 2 or Value > 3 or Value >= 4 or Value == 5 or Value ~= 6
local ConstantKeys = {[1] = "a", [2] = "b", ["a"] = 1, [1.5] = 2, [true] = 3, [false] = 4, [-1] = 5}
local LongMath = ((1 + 2) * (3 - 4)) / ((5 % 6) ^ (math.floor(7 / 8)))
local LongConcat = "a" .. ("b" .. "c") .. ("d" .. ("e" .. "f"))
Passthrough(FoldedString, FoldedLogic, FoldedCompare, FoldedBuiltin, FoldedIf, FoldedAnd, FoldedOr, Infinite, NegativeInfinite, NegativeZero, IsNaN, UsedA, UsedB, SquaredA, SquaredB, EarlyA, EarlyB, UnreachedA, UnreachedB, Result, Fallback, Ternary, Negated, LongCondition, DeepParens, Comparisons, ConstantKeys, LongMath, LongConcat)

local Unused = 0
local function UnusedFunction(UnusedParam)
	return 0
end
