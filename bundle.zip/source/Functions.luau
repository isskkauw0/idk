local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local function ReturnNothing()
	return
end

local function CountArgs(...)
	return select("#", ...), ...
end

local function TypedVariadic(First, ...)	
return First, ...
end

local function Defaults(Required, Maybe, Fallback)	
return (Maybe and{(string.format('%s%s', tostring(Required), tostring(Maybe)))}or{Fallback or "none"
})[1]end

local function ManyParameters(A, B, C, D, E, F, G, H, I, J, K, L)
	return A + B + C + D + E + F + G + H + I + J + K + L
end

local function NestedVararg(...)
	return function(...)
		return ...
	end, ...
end

local function Identity(Value)
	return Value
end

ReturnNothing()
local Void = ReturnNothing()
local VoidTable = {ReturnNothing()}
local X1, X2, X3 = ReturnMany()
local Truncated = (ReturnMany())
local Forwarded = Passthrough(ReturnMany())
local Mixed = Passthrough(0, ReturnMany(), 4)
local Count, First = CountArgs("a", "b", "c")
local CountNil = CountArgs(nil, nil)
local TypedA, TypedB = TypedVariadic(1, "x", "y")
local TypedC = TypedVariadic(2)
local DefaultA = Defaults(1)
local DefaultB = Defaults(1, 2)
local DefaultC = Defaults(1, nil, "x")
local SumA = ManyParameters(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12)
local SumB = ManyParameters(1, 2, 3, 4, 5, 6, 7, 8, 9, ReturnMany())
local InnerFunction, InnerValue = NestedVararg(1, 2)
local InnerResult = InnerFunction(3, 4)
local OuterFunction = NestedVararg()
local Main1, Main2 = ...
local MainArgs = {...}
local MainCount = select("#", ...)
local MainTruncated = (...)

local StringCall = Identity"literal"
local SingleCall = Identity'single'
local TableCall = Identity{1, 2, 3}
local LongCall = Identity[[long]]
local LongLevelCall = Identity[=[level]=]
local ChainedCall = Identity(Identity)(Identity)("done")
local StringChain = Identity"a":upper():lower()
local TableIndexCall = Identity{Key = Identity}.Key("value")
local ParenString = ("%d"):rep(2)
local ParenFormat = ("%d-%d"):format(1, 2)
local ParenTable = ({10, 20, 30})[2]
local ParenCount = #{1, 2, 3}
local ImmediateA = (function(...)
	return ...
end)(1, 2, 3)
local ImmediateB = (function()
	return "immediate"
end)()
Identity(1);
(Identity)(2)
Identity(Identity)(3)
Passthrough(Void, VoidTable, X1, X2, X3, Truncated, Forwarded, Mixed, Count, First, CountNil, TypedA, TypedB, TypedC, DefaultA, DefaultB, DefaultC, SumA, SumB, InnerValue, InnerResult, OuterFunction, Main1, Main2, MainArgs, MainCount, MainTruncated, StringCall, SingleCall, TableCall, LongCall, LongLevelCall, ChainedCall, StringChain, TableIndexCall, ParenString, ParenFormat, ParenTable, ParenCount, ImmediateA, ImmediateB)
