local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Results = {
	math.floor(1.5),
	math.ceil(1.5),
	math.max(1, 2, 3),
	math.min(1, 2, 3),
	math.abs(-1),
	math.sqrt(16),
	math.sin(0),
	math.cos(0),
	math.tan(0),
	math.asin(0),
	math.acos(1),
	math.atan(1),
	math.atan2(1, 1),
	math.exp(0),
	math.log(8, 2),
	math.log10(100),
	math.fmod(7, 3),
	math.modf(1.5),
	math.frexp(8),
	math.ldexp(1, 3),
	math.deg(math.pi),
	math.rad(180),
	math.clamp(5, 1, 3),
	math.sign(-2),
	math.round(1.5),
	math.noise(0.5),
	math.pi,
	math.huge,
}
math.randomseed(1)
local RandomA, RandomB, RandomC = math.random(), math.random(10), math.random(1, 10)
Passthrough(Results, RandomA, RandomB, RandomC)
