local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Integer = 5
if Integer > 10 then
	Integer = 10
elseif Integer < 0 then
	Integer = 0
elseif Integer == 5 then
	Integer = 5
else
	Integer = -1
end
if Integer then end
if not Integer then elseif Integer then else end
if Integer then
	if Integer > 1 then
		if Integer > 2 then
			Integer += 1
		end
	else
		Integer -= 1
	end
end
if Integer == nil then
	Integer = 0
elseif Integer ~= nil and Integer == 6 then
	Integer = 7
end
