local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Integer = 1_000_000
local Hex = 0xFF_FF
local HexUpper = 0XABCDEF
local Binary = 0b1010_1010
local BinaryUpper = 0B11
local Float = 1.5e3
local SmallFloat = 1E-3
local Positive = 1e+3
local Leading = .5
local Trailing = 5.
local Large = 0xFFFFFFFF
local Single = 'single'
local Double = "double"
local Quotes = 'it\'s "quoted"'
local OtherQuotes = "it's \"quoted\""
local Long = [[long
string]]
local LongTrimmed = [[
first newline is skipped]]
local LongLevel = [==[long ]] with ]=] inside]==]
local Escapes = "\a\b\f\n\r\t\v\\\"\'\65\065\x41\u{1F600}\u{48}\0\z
	continued"
local Continued = "line one \
line two"
local Nothing = nil
local Truth, Falsehood = true, false
Passthrough(Integer, Hex, HexUpper, Binary, BinaryUpper, Float, SmallFloat, Positive, Leading, Trailing, Large, Single, Double, Quotes, OtherQuotes, Long, LongTrimmed, LongLevel, Escapes, Continued, Nothing, Truth, Falsehood)
