local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Proxy = setmetatable({}, {
	__index = function()
		return "indexed"
	end,
})
local Results = {
	type(1),
	typeof(1),
	tostring(nil),
	tostring(true),
	tostring(1e15),
	tonumber("ff", 16),
	tonumber("  10  "),
	tonumber("0x10"),
	tonumber("1e2"),
	tonumber("abc"),
	rawget(Proxy, "Missing"),
	rawset(Proxy, "Key", 1),
	rawequal(Proxy, Proxy),
	rawlen({1, 2, 3}),
	next({}),
	next({1}),
	select("#"),
	select("#", nil, nil),
	select(2, "a", "b", "c"),
	select(-1, "a", "b", "c"),
	unpack({1, 2, 3}),
	getmetatable("").__index == string,
}
Passthrough(Results)
