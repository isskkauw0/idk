local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}


local function NativeAdd(A, B)	
return A + B
end


local function CheckedAdd(A, B)	
return A + B
end



local function Both(A)	
return A
end

local Holder = {}


function Holder.Method(Value)
	return Value
end


function Holder:Instance(Value)
	return self, Value
end

local Expression = function(Value)
	return Value + 1
end

local NativeA, NativeB = NativeAdd(1, 2), NativeAdd(3, 4)
local CheckedA, CheckedB = CheckedAdd(1, 2), CheckedAdd(3, 4)
local BothA, BothB = Both(1), Both(2)
local MethodA, MethodB = Holder.Method(1), Holder.Method(2)
local InstanceA = Holder:Instance(1)
local InstanceB = Holder:Instance(2)
local ExpressionA, ExpressionB = Expression(1), Expression(2)
Passthrough(NativeA, NativeB, CheckedA, CheckedB, BothA, BothB, MethodA, MethodB, InstanceA, InstanceB, ExpressionA, ExpressionB)
