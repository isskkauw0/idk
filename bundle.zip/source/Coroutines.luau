local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Thread = coroutine.create(function(First, ...)
	local Second = coroutine.yield(First)
	local Third, Fourth = coroutine.yield(Second, ...)
	return Third, Fourth, coroutine.isyieldable()
end)
local Ok1, Value1 = coroutine.resume(Thread, "a", "b", "c")
local Ok2, Value2, Extra = coroutine.resume(Thread, "x")
local Ok3, Value3, Value4, Yieldable = coroutine.resume(Thread, 1, 2)
local Status = coroutine.status(Thread)
local Wrapped = coroutine.wrap(function(...)
	local Received = {coroutine.yield(...)}
	return #Received
end)
Wrapped(1, 2, 3)
Wrapped(4, 5)
local Running = coroutine.running()
local Closable = coroutine.create(function()
	coroutine.yield()
end)
coroutine.resume(Closable)
coroutine.close(Closable)
local Protected = coroutine.wrap(function()
	pcall(function()
		coroutine.yield(1)
	end)
	return 2
end)
Protected()
Protected()
Passthrough(Ok1, Value1, Ok2, Value2, Extra, Ok3, Value3, Value4, Yieldable, Status, Running)
