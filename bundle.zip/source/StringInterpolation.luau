local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Name = "World"
local Interp = string.format('Hello %s, %s {escaped \n tab\t `tick`', tostring(Name), tostring(1 + 2))
local InterpNested = string.format('Outer %s end', tostring(string.format('Inner %s', tostring(Name))))
local InterpIf = string.format('Value: %s', tostring(Name and"yes" or"no"))
local InterpMulti = string.format('line one\nline two %s', tostring(
Name))
local InterpCall = string.format('%s %s %s %s %s', tostring(string.format("%d", 5)), tostring(#Name), tostring(Sample.X), tostring(Sample["Y"]), tostring(Name:upper()))
local InterpEmpty = ''
local InterpAdjacent = string.format('%s%s%s', tostring(Name), tostring(Name), tostring(1))
local InterpTable = tostring(({1, 2, 3})[1])
local InterpFunction = tostring((function() return "inline" end)())
Name =Name.. "!"
Passthrough(Interp, InterpNested, InterpIf, InterpMulti, InterpCall, InterpEmpty, InterpAdjacent, InterpTable, InterpFunction)
