local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}







local function Generic(Value)	
return Value
end

local function GenericPair(First, Second)	
return {First = First, Second = Second}
end

local function GenericPack(...)	
return ...
end

local function GenericPackBoth(First, ...)	
return First, ...
end

local function Map(Array, Callback)	
local Result= {}
	for Index, Value in Array do
		Result[Index] = Callback(Value)
	end
	return Result
end

local function Asserted(Value)	
return Value 
end

local GenericA, GenericB = Generic(1), Generic("x")
local PairA, PairB = GenericPair(1, "a"), GenericPair(true, {})
local PackA, PackB, PackC = GenericPack(1, "a", true)
local PackD = GenericPack()
local BothA, BothB = GenericPackBoth(1, "a", "b")
local BothC = GenericPackBoth(1)
local MappedA = Map({1, 2, 3}, function(Value)	
return string.format('#%s', tostring(Value))
end)
local MappedB = Map({"a", "b"}, string.upper)
local AssertedA, AssertedB = Asserted(1), Asserted(2)
local AssertedCall = Generic(Sample )
local AssertedTable = {Field = Sample }
local TypedPair= {First = 1, Second = "a"}
local TypedPairDefault= {First = 1, Second = 2}
local TypedTree= {Value = 1, Children = {{Value = 2, Children = {}}}}
local TypedCallback= function(A, B) end
local TypedIndexer= {A = 1}
local TypedAccess= {Id = 1, Name = "x"}
Passthrough(GenericA, GenericB, PairA, PairB, PackA, PackB, PackC, PackD, BothA, BothB, BothC, MappedA, MappedB, AssertedA, AssertedB, AssertedCall, AssertedTable, TypedPair, TypedPairDefault, TypedTree, TypedCallback, TypedIndexer, TypedAccess)
