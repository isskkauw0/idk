local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Buffer = buffer.create(16)
buffer.writeu8(Buffer, 0, 255)
buffer.writei16(Buffer, 1, -2)
buffer.writeu32(Buffer, 4, 0xDEADBEEF)
buffer.writef32(Buffer, 8, 1.5)
buffer.writestring(Buffer, 12, "ab")
local Results = {
	buffer.readu8(Buffer, 0),
	buffer.readi16(Buffer, 1),
	buffer.readu32(Buffer, 4),
	buffer.readf32(Buffer, 8),
	buffer.readstring(Buffer, 12, 2),
	buffer.len(Buffer),
	buffer.tostring(Buffer),
	buffer.len(buffer.fromstring("abc")),
}
buffer.copy(Buffer, 0, Buffer, 8, 4)
buffer.fill(Buffer, 0, 0, 16)
Passthrough(Results)
