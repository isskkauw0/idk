local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Results = {
	bit32.band(0xFF, 0x0F),
	bit32.bor(1, 2),
	bit32.bxor(3, 1),
	bit32.bnot(0),
	bit32.lshift(1, 4),
	bit32.rshift(16, 2),
	bit32.arshift(-16, 2),
	bit32.lrotate(1, 1),
	bit32.rrotate(1, 1),
	bit32.extract(0xFF, 4, 4),
	bit32.replace(0, 0xF, 4, 4),
	bit32.btest(1, 1),
	bit32.countlz(1),
	bit32.countrz(8),
	bit32.byteswap(1),
	utf8.char(72, 228, 8364),
	utf8.charpattern,
	utf8.len("häl"),
	utf8.codepoint("häl", 1, -1),
	utf8.offset("häl", 2),
	os.time(),
	os.clock(),
	os.date("%Y-%m-%d", 0),
	os.time({year = 2020, month = 1, day = 1}),
	os.difftime(2, 1),
}
Passthrough(Results)
