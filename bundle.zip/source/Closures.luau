local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local function MakeCounter()
	local Count = 0
	return function()
		Count =Count+ 1
		return Count
	end, function()
		Count = 0
	end
end

local function Outer()
	local A = 1
	return function()
		local B = 2
		return function()
			local C = 3
			return function()
				A =A+ 1
				B =B+ 1
				C =C+ 1
				return A + B + C
			end
		end
	end
end

local function Factorial(N)	
if N <= 1 then
		return 1
	end
	return N * Factorial(N - 1)
end

local function TailCall(N)	
if N == 0 then
		return 0
	end
	return TailCall(N - 1)
end

local IsEven, IsOdd

function IsEven(N)
	if N == 0 then
		return true
	end
	return IsOdd(N - 1)
end

function IsOdd(N)
	if N == 0 then
		return false
	end
	return IsEven(N - 1)
end

local Forward

Forward = function(N)
	return (N > 0 and{(Forward(N - 1) )}or{N
})[1]end

local Increment, Reset = MakeCounter()
local IncrementOther = MakeCounter()
Increment()
Increment()
Reset()
IncrementOther()

local Closures = {}
for Index = 1, 3 do
	Closures[Index] = function()
		return Index
	end
end
for Index, Value in {10, 20, 30} do
	Closures[Index + 3] = function()
		return Index + Value
	end
end
local Step = 0
while Step < 3 do
	Step =Step+ 1
	local Captured = Step
	Closures[Step + 6] = function()
		Captured =Captured+ 1
		return Captured
	end
end
for Index = 1, #Closures do
	Closures[Index]()
end

local DeepA = Outer()()()
local DeepB = Outer()()()
DeepA()
DeepA()
DeepB()
local FactorialA, FactorialB = Factorial(5), Factorial(10)
local TailA, TailB = TailCall(10), TailCall(100)
local EvenA, OddA = IsEven(10), IsOdd(7)
local ForwardA, ForwardB = Forward(3), Forward(0)
Passthrough(FactorialA, FactorialB, TailA, TailB, EvenA, OddA, ForwardA, ForwardB)
