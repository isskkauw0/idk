local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Table = {
	1,
	2;
	3,
	Key = "value",
	["Spaced Key"] = true,
	["end"] = 1,
	["if"] = 2,
	[1 + 10] = "computed",
	[""] = "empty",
	["1abc"] = "digit start",
	Nested = {Deep = {Deeper = {1, 2, 3}}},
	Func = function(Self, X)
		return X
	end,
	Method = function(Self)
		return Self
	end,
}
local EmptyTable = {}
local TrailingSemicolon = {1, 2, 3;}
local Big = {
	1, 2, 3, 4, 5, 6, 7, 8,
	9, 10, 11, 12, 13, 14, 15, 16,
	17, 18, 19, 20, 21, 22, 23, 24,
	25, 26, 27, 28, 29, 30, 31, 32,
	33, 34, 35, 36, 37, 38, 39, 40,
	41, 42, 43, 44, 45, 46, 47, 48,
	49, 50, 51, 52, 53, 54, 55, 56,
	57, 58, 59, 60, 61, 62, 63, 64,
}
local InTable = {ReturnMany()}
local InTableMiddle = {ReturnMany(), 10}
local InTableEnd = {10, ReturnMany()}
local InTableVararg = {Passthrough(1, 2), Passthrough(3, 4)}
local InTableParen = {(ReturnMany())}
local KeyedExpand = {Key = ReturnMany(), ReturnMany()}
Table.Key = nil
Table["Key"] = "again"
Table[1] += 10
Table.Nested.Deep.Deeper[1] = 99
Table["end"] = nil
Table[1], Table[2] = Table[2], Table[1]
Table[#Table + 1] = "appended"
Table[Table] = Table
Table[Passthrough] = Passthrough(Table)
local Missing = Table.Missing
local MissingDeep = Table.Nested and Table.Nested.Deep and Table.Nested.Deep.Missing
Passthrough(EmptyTable, TrailingSemicolon, Big, InTable, InTableMiddle, InTableEnd, InTableVararg, InTableParen, KeyedExpand, Missing, MissingDeep)

local Callbacks = {
	function() return 1 end,
	function(...) return ... end,
	Passthrough,
}
local Complex = {
	Callbacks = Callbacks,
	[Passthrough] = "function key",
	[true] = "boolean key",
	[1.5] = "float key",
	["nested"] = {["deeper"] = {["deepest"] = {}}},
}
Complex.Callbacks[1]()
Complex.Callbacks[2](1, 2, 3)
Complex["nested"]["deeper"].deepest.Field = 1
Complex[Passthrough] = nil
Complex.Callbacks[3](Complex.Callbacks[2](Complex.Callbacks[1]()))
