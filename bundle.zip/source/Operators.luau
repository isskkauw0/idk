local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Integer = 5
local Float = 2.5
local Text = "abc"
local Arithmetic = 1 + 2 - math.floor(3 * 4 / 5 / 6 )% 7 ^ 2 ^ 3
local Variable = Integer + Float - math.floor(Integer * Float / Integer / Float )% Integer ^ Float ^ 2
local GroupedMath = ((1 + 2) * (3 - 4)) / ((5 % 6) ^ (math.floor(7 / 8)))
local Unary = -Integer + -(-Float) - #Text
local SpacedUnary = - -1
local DoubleNot = not not Integer
local Concat = "a" .. "b" .. 1 .. 2 .. Text
local ConcatGrouped = ("a" .. "b") .. ("c" .. ("d" .. "e"))
local Compare = Integer < Float and Float <= Integer and Integer > 2 and Integer >= 5 and Integer ~= Float and Integer == 5
local StringCompare = "a" < "b" and "b" >= "a"
local Logic = not Integer or Float and Text or nil
local Precedence = not (1 == 2) and #Text == 3 or -2 ^ 2 == -4
local Chain = nil or false or Text
local Short = Integer and "left" or "right"
local Power = 2 ^ -1 ^ 2
local Combined = Integer + Float .. Text .. Integer * 2
local Length = #Text + #{1, 2, 3} + #"literal"
local Equality = Text == "abc" and Integer ~= nil and Float ~= false
local CastPrecedence = Integer + (Float )
local TypeChecks = typeof(Sample) == "table" and type(Sample) == "table"
local Branch = Integer > 0 and"positive" or(Integer < 0 and"negative" or"zero"
)local Nested = (Integer and{Float and 1 or 2 }or{3
})[1]local InCall = tostring(Integer and 1 or 2)
local InTable = {Integer and 1 or 2, Key = Float and"a" or"b"}
local InCondition = ((Integer and{Float }or{Text})[1]) and"yes" or"no"
Passthrough(Arithmetic, Variable, GroupedMath, Unary, SpacedUnary, DoubleNot, Concat, ConcatGrouped, Compare, StringCompare, Logic, Precedence, Chain, Short, Power, Combined, Length, Equality, CastPrecedence, TypeChecks, Branch, Nested, InCall, InTable, InCondition)
