local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local TypedNumber, TypedString= 1, "x"
local TypedOptional= nil
local TypedFunction= function(Value)
	return Value
end
local TypedTable= {}
local C, D, E = 1, 2
local F, G = 1, 2, 3
local H, I, J = ReturnMany()
local K, L = ReturnMany(), 10
local M, N, O = 10, ReturnMany()
local P = (ReturnMany())
local Q, R = Passthrough()
local Cast = Sample 
local Casted = (TypedNumber ) + 1
local DoubleCast = (Sample ) 
local Swap1, Swap2 = 1, 2
Swap1, Swap2 = Swap2, Swap1
Sample.X, Sample.Y = Sample.Y, Sample.X
TypedTable.A, TypedTable["B"], TypedTable[TypedString] = 1, 2, 3
TypedTable[Swap1], TypedTable[Swap2] = ReturnMany()
GlobalValue = 1
GlobalValue =GlobalValue+ 1
GlobalValue, TypedTable.A = TypedTable.A, GlobalValue
GlobalValue = nil
Passthrough(TypedOptional, TypedFunction, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, Cast, Casted, DoubleCast)
