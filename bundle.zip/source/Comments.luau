local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local A = 1 -- trailing comment
local B --[[ inline block ]] = 2
local --[[ before name ]] C --[[ after name ]], --[[ before second ]] D = 3, 4
local E = --[[ before value ]] 5 --[[ after value ]]
local F = 1 --[[ between ]] + --[[ operators ]] 2 --[=[ level one ]=] * 3
local G = {
	1, -- first
	2, --[[ second ]] 3,
	-- whole line inside table
	Key = --[[ before value ]] "value", -- after pair
	--[[ multi
	line
	inside table ]]
	Other = true,
}

local function Commented(--[[ no params ]]) -- after params
	return --[[ before value ]] 1 -- after
end

local function Multi( --[[ first ]] First, -- after first
	Second --[[ after second ]]
)
	return First, Second -- values
end


local function Attributed() -- after
	return 1
end

local Called = Commented --[[ before call ]] ( --[[ inside call ]] ) --[[ after call ]]
local CalledAgain = Commented() -- again
local Indexed = G --[[ before dot ]] . --[[ after dot ]] Key
local Method = ("x") --[[ before colon ]] : --[[ after colon ]] upper()
local R1, R2 = Multi(
	1, -- one
	2 --[[ two ]]
)
local R3, R4 = Multi(3, 4)
local Attr1, Attr2 = Attributed(), Attributed()

--[[ simple block ]]
--[=[ level one with ]] inside ]=]
--[==[ level two with ]] and ]=] inside ]==]
--[[]]
--[=[]=]
--[[
multi line
block
]]
--[==[
multi line
level two ]] ]=]
]==]
---[[ triple dash is a line comment
local H = 1
---]]
--[ single bracket is a line comment
--[= bracket equals is a line comment
--[=x not a long comment
--
---
----------
-- unicode: héllo 😀 ✓
--	tab after dashes
-- local Z = 1
--[[ local Z = 1 ]]
--!strict
--!nonstrict
--!native
--!nocheck

local S1 = "-- not a comment"
local S2 = '--[[ not a comment ]]'
local S3 = [[-- not a comment]]
local S4 = [=[
--[[ nested-looking ]]
]=]
local S5 = string.format('-- %s --[[ also not ]]', tostring(A))
local S6 = "a" .. "--" .. "b"
local S7 = 1 - -1
local S8 = 1 - - -1
local S9 = tostring(A)

local Typed= 1
local TypedFunction= function(Value) -- after function
	return Value
end
local TypedA, TypedB = TypedFunction(1), TypedFunction(2)







if A == 1 then -- after then
	-- only a comment in body
elseif --[[ in condition ]] A == 2 then
else -- after else
end -- after end
for Index = 1 --[[ start ]], 2 --[[ stop ]] do -- after do
local __DARKLUA_CONTINUE_1=false repeat __DARKLUA_CONTINUE_1=true	break -- after continue
until true if not __DARKLUA_CONTINUE_1 then break end end
while false do --[[ empty ]] end
repeat -- after repeat
until --[[ before condition ]] true -- after until
for Index, Value in --[[ before iterator ]] {1} do -- after
	break --[[ after break ]]
end
Passthrough(B, C, D, E, F, Called, CalledAgain, Indexed, Method, R1, R2, R3, R4, Attr1, Attr2, H, S1, S2, S3, S4, S5, S6, S7, S8, S9, Typed, TypedA, TypedB)
