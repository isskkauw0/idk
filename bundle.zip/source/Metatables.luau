local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Vector = {}
Vector.__index = Vector



function Vector.New(X, Y)	
return setmetatable({X = X, Y = Y}, Vector)
end

function Vector.__add(Left, Right)	
return Vector.New(Left.X + Right.X, Left.Y + Right.Y)
end

function Vector.__sub(Left, Right)	
return Vector.New(Left.X - Right.X, Left.Y - Right.Y)
end

function Vector.__mul(Left, Right)	
return Vector.New(Left.X * Right, Left.Y * Right)
end

function Vector.__div(Left, Right)	
return Vector.New(Left.X / Right, Left.Y / Right)
end

function Vector.__idiv(Left, Right)	
return Vector.New(math.floor(Left.X / Right), math.floor(Left.Y / Right))
end

function Vector.__mod(Left, Right)	
return Vector.New(Left.X % Right, Left.Y % Right)
end

function Vector.__pow(Left, Right)	
return Vector.New(Left.X ^ Right, Left.Y ^ Right)
end

function Vector.__unm(Self)	
return Vector.New(-Self.X, -Self.Y)
end

function Vector.__concat(Left, Right)
	return "vector"
end

function Vector.__len(Self)	
return 2
end

function Vector.__eq(Left, Right)	
return Left.X == Right.X and Left.Y == Right.Y
end

function Vector.__lt(Left, Right)	
return Left.X < Right.X
end

function Vector.__le(Left, Right)	
return Left.X <= Right.X
end

function Vector.__call(Self, Scale)	
return Self * Scale
end

function Vector.__tostring(Self)	
return string.format('(%s, %s)', tostring(Self.X), tostring(Self.Y))
end

function Vector.__newindex(Self, Key, Value)
	rawset(Self, Key, Value)
end

function Vector:Length()	
return (self.X ^ 2 + self.Y ^ 2) ^ 0.5
end

local Animal = {}
Animal.__index = Animal

function Animal.New(Name)
	local Self = setmetatable({}, Animal)
	Self.Name = Name
	return Self
end

function Animal:Speak()
	return string.format('%s makes a sound', tostring(self.Name))
end

local Dog = setmetatable({}, {__index = Animal})
Dog.__index = Dog

function Dog.New(Name)
	local Self = Animal.New(Name)
	return setmetatable(Self, Dog)
end

function Dog:Speak()
	return Animal.Speak(self) .. " (woof)"
end

local Left = Vector.New(1, 2)
local Right = Vector.New(3, 4)
local Combined = (Left + Right) * 2 - Left / 2
local Divided = math.floor(Left / 2
)local Modded = Left % 2
local Powered = Left ^ 2
local Negated = -Left
local IsEqual = Left == Right or Left ~= Right
local IsLess = Left < Right and Left <= Right and Left > Right and Left >= Right
local Called = Left(3)
local Size = #Left
local Joined = Left .. Right
local JoinedString = Left .. "text"
local Text = tostring(Left)
local Length = Left:Length()
Left.Z = 5
local Weak = setmetatable({}, {__mode = "k", __metatable = "locked"})
local Locked = getmetatable(Weak)
local Cached = setmetatable({}, {
	__index = function(Self, Key)
		local Value = Key * 2
		rawset(Self, Key, Value)
		return Value
	end,
})
local FromCache = Cached[5] + Cached[10]
local Proxy = setmetatable({}, {__index = Sample, __newindex = Sample})
Proxy.X = 10
local Pet = Dog.New("Rex")
local Cat = Animal.New("Cat")
local Speech = Pet:Speak() .. Cat:Speak()
local IsDog = getmetatable(Pet) == Dog
Passthrough(Combined, Divided, Modded, Powered, Negated, IsEqual, IsLess, Called, Size, Joined, JoinedString, Text, Length, Locked, FromCache, Speech, IsDog)
