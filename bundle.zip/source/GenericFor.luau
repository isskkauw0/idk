local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Total = 0
local Items = {10, 20, 30}
local Dictionary = {A = 1, B = 2, C = 3}

local function Iterate(Limit)
	local Current = 0
	return function()
		Current =Current+ 1
		if Current <= Limit then
			return Current, Current * 2
		end
		return nil
	end
end

local function Stateless(State, Index)
	Index =Index+ 1
	if State[Index] then
		return Index, State[Index]
	end
	return nil
end

local IterTable = setmetatable({}, {
	__iter = function(Self)
		return function(_, Last)
			if not Last then
				return 1
			end
			return nil
		end, Self, nil
	end,
})

for Index, Value in Items do
	Total =Total+ (Index + Value
)end
for Index, Value in {"a", "b"} do
	Total =Total+ (Index + #Value
)end
for Key, Value in Dictionary do
	Total =Total+ Value
end
for Key, Value in pairs(Dictionary) do
local __DARKLUA_CONTINUE_4=false repeat	if Key == "A" then
__DARKLUA_CONTINUE_4=true		break
	end
	Total =Total+ Value
__DARKLUA_CONTINUE_4=true until true if not __DARKLUA_CONTINUE_4 then break end end
for Index, Value in ipairs(Items) do
	if Index > 2 then
		break
	end
	Total =Total+ Value
end
for Key, Value in next, Dictionary do
	Total =Total+ Value
end
for Key, Value in next, Dictionary, nil do
	Total =Total+ Value
end
for Word in string.gmatch("a b c", "%a+") do
	Total =Total+ #Word
end
for Position, Code in utf8.codes("hé") do
	Total =Total+ (Position + Code
)end
for Value in coroutine.wrap(function()
	for Index = 1, 3 do
		coroutine.yield(Index)
	end
end) do
	Total =Total+ Value
end
for Index, Double in Iterate(3) do
	Total =Total+ (Index + Double
)end
for Index, Double in Iterate(5) do
	Total =Total+ (Index - Double
)end
for Index, Value in Stateless, {5, 6, 7}, 0 do
	Total =Total+ Value
end
for Index, Value in Stateless, Items, 0 do
	Total =Total+ Value
end
for Value in IterTable do
	Total =Total+ Value
end
for Value in IterTable do
	Total =Total- Value
end
for _, Value in {1, 2, 3} do
	for _, Inner in {4, 5, 6} do
local __DARKLUA_CONTINUE_19=false repeat		if Inner == 5 then
			break
		end
		if Value == 2 then
__DARKLUA_CONTINUE_19=true			break
		end
		Total =Total+ Inner
__DARKLUA_CONTINUE_19=true until true if not __DARKLUA_CONTINUE_19 then break end	end
end
