local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Total = 0
local Items = {1, 2, 3}
for Index = 1, 10 do
local __DARKLUA_CONTINUE_1=false repeat	if Index % 2 == 0 then
__DARKLUA_CONTINUE_1=true		break
	end
	if Index > 7 then
		break
	end
	Total =Total+ Index
__DARKLUA_CONTINUE_1=true until true if not __DARKLUA_CONTINUE_1 then break end end
for Index = 10, 1, -1 do
	Total =Total+ Index
end
for Index = 1, 2, 0.5 do
	Total =Total+ Index
end
for Index = 1, 0 do
end
for Index = 1, 0, -1 do
	Total =Total+ Index
end
for Index = 1, -1, -0.5 do
	Total =Total+ Index
end
for Index = 0, 1, 0.25 do
	Total =Total+ Index
end
for Index = 1, #Items do
	Total =Total+ Items[Index]
end
for Index = #Items, 1, -1 do
	Total =Total+ Items[Index]
end
for Index= 1, 3 do
	Total =Total+ Index
end
for Index = 1, 3, 1 do
	for Inner = Index, 3 do
local __DARKLUA_CONTINUE_12=false repeat		if Inner == 2 then
__DARKLUA_CONTINUE_12=true			break
		end
		Total =Total+ Inner
__DARKLUA_CONTINUE_12=true until true if not __DARKLUA_CONTINUE_12 then break end	end
end
for Index = 1, math.huge do
	break
end
for Index = Total, Total + 2 do
	Total =Total- 1
end
