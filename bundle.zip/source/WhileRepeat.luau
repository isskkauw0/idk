local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Counter = 100
local Sum = 0
while Counter > 0 do
	Counter -= 1
	if Counter == 50 then
		break
	end
end
while true do
	break
end
while false do
end
while Sum < 10 do
	Sum += 1
	if Sum % 2 == 0 then
		continue
	end
	Sum += 1
end
repeat
	local Finished = true
	Sum += 1
until Finished
repeat
	Sum -= 1
until Sum < 0 or false
repeat
until true
repeat
	Sum += 1
	if Sum % 2 == 0 then
		continue
	end
	if Sum > 20 then
		break
	end
until Sum >= 30
while Sum > 0 do
	Sum -= 1
	while Sum > 5 do
		Sum -= 2
		if Sum < 10 then
			break
		end
	end
end
