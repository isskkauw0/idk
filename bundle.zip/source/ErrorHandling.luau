local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Success, Message = pcall(error, "failure")
local SuccessTable, Payload = pcall(function()
	error({Code = 1})
end)
local SuccessLevel = pcall(function()
	error("level", 2)
end)
local SuccessNil = pcall(error)
local Handled = xpcall(function()
	error("handled")
end, function(Error)
	return string.format('handler: %s', tostring(Error))
end)
local Asserted, AssertMessage = pcall(assert, false, "assert failed")
local AssertValue = assert(1, "unused message")
local Returned = {pcall(ReturnMany)}
local WithArgs = select("#", pcall(Passthrough, 1, 2, 3))
local Traced = xpcall(error, debug.traceback, "traced")
local Nested = pcall(pcall, error, "nested")
Passthrough(Success, Message, SuccessTable, Payload, SuccessLevel, SuccessNil, Handled, Asserted, AssertMessage, AssertValue, Returned, WithArgs, Traced, Nested)
