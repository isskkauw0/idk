local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Integer = 7
local Text = "t"
local Holder = {Number = 2, Text = "h", [1] = 5, Nested = {Value = 3}}
Integer =Integer+ 1
Integer =Integer- 1
Integer =Integer* 2
Integer =Integer/ 2
Integer =math.floor(Integer/ 3
)Integer =Integer% 2
Integer =Integer^ 2
Text =Text.. "!"
Text =Text.. 1 .. 2
Holder.Number =Holder.Number+ 1
Holder.Number =Holder.Number- Holder.Nested.Value
Holder["Number"]=Holder["Number"]* 2
Holder[1]=math.floor(Holder[1]/ 2
)Holder.Text =Holder.Text.. Text
do local __DARKLUA_VAR=Holder.Nested __DARKLUA_VAR.Value =__DARKLUA_VAR.Value^ 2
end Holder[Text] = Integer
Holder[Text]=Holder[Text]+ 1
GlobalCounter = 0
GlobalCounter =GlobalCounter+ 1
GlobalCounter =GlobalCounter.. ""
do local __DARKLUA_VAR0=Passthrough(Holder)__DARKLUA_VAR0.Number =__DARKLUA_VAR0.Number+ 1
end do local __DARKLUA_VAR1=Passthrough(Holder)__DARKLUA_VAR1[1]=__DARKLUA_VAR1[1]- 1
end do local __DARKLUA_VAR2=Passthrough(Holder)__DARKLUA_VAR2.Text =__DARKLUA_VAR2.Text.. "?"
end