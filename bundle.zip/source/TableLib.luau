local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Items = {5, 3, 1}
local Frozen = table.freeze({1, 2, 3})
local Copy = table.clone(Items)
table.insert(Items, 4)
table.insert(Items, 1, 0)
table.remove(Items)
table.remove(Items, 1)
table.sort(Items)
table.sort(Items, function(A, B)
	return A > B
end)
table.move(Items, 1, 2, 3)
table.move(Items, 1, 2, 1, {})
table.clear(Copy)
local Results = {
	table.concat(Items, ",", 1, 2),
	table.unpack(Items, 1, 2),
	table.pack(table.unpack(Items)),
	table.find(Items, 3),
	table.create(3, 0),
	table.isfrozen(Frozen),
	#table.pack(),
}
Passthrough(Results)
