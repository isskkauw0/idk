local function Passthrough(...)
	return ...
end

local function ReturnMany()
	return 1, 2, 3
end

local Sample = {X = 1, Y = 2}

local Text = "Hello, World"
local Results = {
	string.format("%d %5.2f %s %q %x %X %o %c %e %g %%", 1, 2.5, "s", "q", 255, 255, 8, 65, 1.5, 1.5),
	string.format("%-5s|%05d|%+d|%#x", "a", 42, 3, 255),
	string.rep("ab", 3),
	string.sub(Text, 2, -2),
	string.upper(Text),
	string.lower(Text),
	string.len(Text),
	string.reverse(Text),
	string.byte("A"),
	string.byte("abc", 1, -1),
	string.char(72, 105),
	string.find(Text, "o"),
	string.find("a.b", ".", 1, true),
	string.match("key=value", "(%w+)=(%w+)"),
	string.match("2024-01-02", "(%d+)-(%d+)-(%d+)"),
	string.match("abc", "()b()"),
	string.gsub(Text, "o", "0"),
	string.gsub(Text, "l", {l = "L"}),
	string.gsub(Text, "(l)(l)", function(A, B)
		return B .. A
	end),
	string.gsub("abc", "%w", "%0%0"),
	string.gsub("THE (quick) fox", "%((%w+)%)", "<%1>"),
	string.find("THE (quick) fox", "%b()"),
	string.gsub("hello world", "%f[%w]%w+", string.upper),
	string.split("a,b,c", ","),
	string.pack("<I4", 1),
	string.unpack("<I4", string.pack("<I4", 1)),
	string.packsize("<I4"),
	Text:lower():upper():len(),
	Text:sub(1, 1):byte(),
}
Passthrough(Results)
