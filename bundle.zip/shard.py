import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
root = os.getcwd()
preset = sys.argv[1]
shard = int(sys.argv[2])
configs = sorted(os.listdir(f"cfg/{preset}"))[shard::int(sys.argv[3])]
jobs = [(c, f) for c in configs for f in sorted(os.listdir("source"))]
def run(job):
	out = f"{root}/out/{preset}/{job[0][:-4]}/{job[1]}"
	os.makedirs(os.path.dirname(out), exist_ok=True)
	r = subprocess.run(["timeout", "900", "lua5.1", "cli.lua", "--config", f"{root}/cfg/{preset}/{job[0]}", "--LuaU", "--out", out, f"{root}/source/{job[1]}"], cwd=f"{root}/prometheus", capture_output=True)
	if r.returncode != 0:
		if os.path.exists(out):
			os.remove(out)
		return f"{preset}/{job[0][:-4]}/{job[1]}"
with ThreadPoolExecutor(os.cpu_count()) as ex:
	fails = [x for x in ex.map(run, jobs) if x]
open(f"fail-{preset}-{shard}.txt", "w").write("\n".join(fails))
